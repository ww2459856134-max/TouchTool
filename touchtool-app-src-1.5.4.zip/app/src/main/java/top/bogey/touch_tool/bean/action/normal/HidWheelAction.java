package top.bogey.touch_tool.bean.action.normal;

import android.graphics.Bitmap;

import com.google.gson.JsonObject;

import top.bogey.touch_tool.MainApplication;
import top.bogey.touch_tool.R;
import top.bogey.touch_tool.bean.action.ActionType;
import top.bogey.touch_tool.bean.action.parent.ExecuteAction;
import top.bogey.touch_tool.bean.other.log.LogInfo;
import top.bogey.touch_tool.bean.other.log.NormalLog;
import top.bogey.touch_tool.bean.pin.Pin;
import top.bogey.touch_tool.bean.pin.pin_objects.PinBoolean;
import top.bogey.touch_tool.bean.pin.pin_objects.pin_number.PinInteger;
import top.bogey.touch_tool.bean.pin.pin_objects.pin_string.PinSingleSelect;
import top.bogey.touch_tool.service.MainAccessibilityService;
import top.bogey.touch_tool.service.TaskRunnable;
import top.bogey.touch_tool.utils.DisplayUtil;
import top.bogey.touch_tool.utils.HidClient;

// HID 滚轮：通过 ESP32 蓝牙 HID 发送滚轮滚动（v1.5.0 固件新增 0x0A 指令字）
// v1.5.2 增强：
//   · 滚动模式：自动校准（推荐）/ 强制 HID / 强制触摸滑动(drag)
//     自动校准 = 发一次 HID 滚轮后截屏对比，屏幕没动就自动改发 drag 并按设备记住，
//     之后直接走记住的通道，不再反复截屏
//   · 滚动位置：屏幕中心 / 上 1/3 / 下 1/3 / 自定义坐标——drag 模式的滑动落点
//     可避开输入框、视频进度条等敏感区域（HID 模式下位置无意义，滚轮本来就是全局的）
// 协议：0x0A + {"d":±1,"h":±1,"n":格数,"i":间隔ms,"m":0|1,"x":px,"y":px}
// 旧固件收不到只会超时一次，不影响原有功能
public class HidWheelAction extends ExecuteAction {
    // 与 R.array.hid_wheel_type 顺序一致
    private static final int[][] DIRS = {
            {1, 0},    // 上滚
            {-1, 0},   // 下滚
            {0, 1},    // 右滚
            {0, -1},   // 左滚
    };
    // 与 R.array.hid_wheel_mode 顺序一致
    private static final int MODE_AUTO = 0;
    private static final int MODE_HID = 1;
    private static final int MODE_DRAG = 2;
    // 与 R.array.hid_wheel_pos 顺序一致
    private static final int POS_CENTER = 0;
    private static final int POS_UPPER = 1;
    private static final int POS_LOWER = 2;
    private static final int POS_CUSTOM = 3;

    private final transient Pin dirPin = new Pin(new PinSingleSelect(R.array.hid_wheel_type), R.string.hid_wheel_action_dir);
    private final transient Pin ticksPin = new Pin(new PinInteger(5), R.string.hid_wheel_action_ticks);
    private final transient Pin intervalPin = new Pin(new PinInteger(40), R.string.hid_wheel_action_interval);
    private final transient Pin modePin = new Pin(new PinSingleSelect(R.array.hid_wheel_mode), R.string.hid_wheel_action_mode);
    private final transient Pin posPin = new Pin(new PinSingleSelect(R.array.hid_wheel_pos), R.string.hid_wheel_action_pos);
    private final transient Pin posXPin = new Pin(new PinInteger(540), R.string.hid_wheel_action_pos_x);
    private final transient Pin posYPin = new Pin(new PinInteger(1335), R.string.hid_wheel_action_pos_y);
    // v1.5.2b: 随机偏移针脚——填的是幅度，每次执行在实际偏移 ∈ [-幅度, +幅度] 内随机取，
    // 落点 = 位置坐标 + 随机偏移，每次运行都不同（防轨迹固定被识别）；0 = 不偏移
    private final transient Pin offXPin = new Pin(new PinInteger(0), R.string.hid_wheel_action_off_x);
    private final transient Pin offYPin = new Pin(new PinInteger(0), R.string.hid_wheel_action_off_y);
    private final transient Pin successPin = new Pin(new PinBoolean(), R.string.file_action_success, true);

    public HidWheelAction() {
        super(ActionType.HID_WHEEL);
        addPins(dirPin, ticksPin, intervalPin, modePin, posPin, posXPin, posYPin, offXPin, offYPin, successPin);
    }

    public HidWheelAction(JsonObject jsonObject) {
        super(jsonObject);
        reAddPins(dirPin, ticksPin, intervalPin, modePin, posPin, posXPin, posYPin, offXPin, offYPin, successPin);
    }

    @Override
    public void execute(TaskRunnable runnable, Pin pin) {
        String host = HidClient.getConfigHost();
        int port = HidClient.getConfigPort();
        if (host == null && !HidClient.useBle()) {
            runnable.addLog(new LogInfo(new NormalLog("[HID滚轮] 请先在 设置 中配置 ESP32 设备")), 0);
            successPin.getValue(PinBoolean.class).setValue(false);
            executeNext(runnable, outPin);
            return;
        }

        PinSingleSelect dirPinValue = (PinSingleSelect) getPinValue(runnable, dirPin);
        int dirIndex = dirPinValue == null ? 0 : dirPinValue.getIndex();
        int[] dir = DIRS[Math.max(0, Math.min(DIRS.length - 1, dirIndex))];

        int ticks = Math.max(1, ((PinInteger) getPinValue(runnable, ticksPin)).intValue());
        long interval = Math.max(0, ((PinInteger) getPinValue(runnable, intervalPin)).intValue());

        PinSingleSelect modeValue = (PinSingleSelect) getPinValue(runnable, modePin);
        int modeSel = modeValue == null ? MODE_AUTO : modeValue.getIndex();

        // 滚动位置 → drag 滑动区域中心（像素），叠加随机偏移后发出
        android.util.Size size = DisplayUtil.getScreenSize(MainApplication.getInstance());
        PinSingleSelect posValue = (PinSingleSelect) getPinValue(runnable, posPin);
        int posSel = posValue == null ? POS_CENTER : posValue.getIndex();
        int px, py;
        switch (Math.max(0, Math.min(POS_CUSTOM, posSel))) {
            case POS_UPPER -> { px = size.getWidth() / 2; py = size.getHeight() / 3; }
            case POS_LOWER -> { px = size.getWidth() / 2; py = size.getHeight() * 2 / 3; }
            case POS_CUSTOM -> {
                px = Math.max(0, ((PinInteger) getPinValue(runnable, posXPin)).intValue());
                py = Math.max(0, ((PinInteger) getPinValue(runnable, posYPin)).intValue());
            }
            default -> { px = size.getWidth() / 2; py = size.getHeight() / 2; }
        }
        // 随机偏移：幅度针脚 → 实际偏移在 ±幅度 内均匀随机，每次执行落点都不同
        int ampX = Math.max(0, Math.min(10000, ((PinInteger) getPinValue(runnable, offXPin)).intValue()));
        int ampY = Math.max(0, Math.min(10000, ((PinInteger) getPinValue(runnable, offYPin)).intValue()));
        if (ampX > 0) px += java.util.concurrent.ThreadLocalRandom.current().nextInt(-ampX, ampX + 1);
        if (ampY > 0) py += java.util.concurrent.ThreadLocalRandom.current().nextInt(-ampY, ampY + 1);
        // 落点 clamp 进屏幕（固件端还会对滑动起终点做一次 clamp）
        px = Math.max(0, Math.min(size.getWidth() - 1, px));
        py = Math.max(0, Math.min(size.getHeight() - 1, py));

        StringBuilder hexLog = new StringBuilder();
        boolean ok;

        if (modeSel == MODE_HID) {
            ok = HidClient.sendWheel(host, port, dir[0], dir[1], ticks, interval, 0, px, py, hexLog);
            ok = logResult(runnable, ok, dirIndex, ticks, "HID", hexLog);
        } else if (modeSel == MODE_DRAG) {
            ok = HidClient.sendWheel(host, port, dir[0], dir[1], ticks, interval, 1, px, py, hexLog);
            ok = logResult(runnable, ok, dirIndex, ticks, "drag", hexLog);
        } else {
            // 自动校准：优先用记住的模式；没记住就先试 HID，截屏对比无变化再切 drag
            int remembered = HidClient.getRememberedWheelMode();
            if (remembered == 0 || remembered == 1) {
                String tag = remembered == 0 ? "HID" : "drag";
                ok = HidClient.sendWheel(host, port, dir[0], dir[1], ticks, interval, remembered, px, py, hexLog);
                ok = logResult(runnable, ok, dirIndex, ticks, tag, hexLog);
            } else {
                ok = calibrateAndRun(runnable, host, port, dir, dirIndex, ticks, interval, px, py, hexLog);
            }
        }

        successPin.getValue(PinBoolean.class).setValue(ok);
        executeNext(runnable, outPin);
    }

    /** 自动校准：HID 试滚 → 截屏对比 → 无变化切 drag 并记住。返回动作是否成功 */
    private boolean calibrateAndRun(TaskRunnable runnable, String host, int port,
                                    int[] dir, int dirIndex, int ticks, long interval,
                                    int px, int py, StringBuilder hexLog) {
        // 校准用小剂量，避免 HID 恰好可用时滚过头
        int probeTicks = Math.min(ticks, 3);
        Bitmap before = capture(runnable);
        boolean hidOk = HidClient.sendWheel(host, port, dir[0], dir[1], probeTicks, interval, 0, px, py, hexLog);
        if (!hidOk) {
            // HID 发送失败（BLE/UDP 都不通）——直接试 drag，同样会失败并给出统一提示
            boolean ok = HidClient.sendWheel(host, port, dir[0], dir[1], ticks, interval, 1, px, py, hexLog);
            return logResult(runnable, ok, dirIndex, ticks, "drag", hexLog);
        }
        runnable.sleep((int) Math.max(600, interval * probeTicks + 400));
        Bitmap after = capture(runnable);

        if (screenChanged(before, after)) {
            HidClient.saveRememberedWheelMode(0);
            runnable.addLog(new LogInfo(new NormalLog("[HID滚轮] 校准完成：HID 原生滚轮可用，已记住")), 0);
            // 校准只滚了 probeTicks 格，补足剩余格数
            if (ticks > probeTicks) {
                runnable.sleep((int) Math.max(100, interval * (ticks - probeTicks)));
            }
            return true;
        }

        // 屏幕没动 → 这台设备不认 HID 滚轮，切 drag 兜底
        boolean ok = HidClient.sendWheel(host, port, dir[0], dir[1], ticks, interval, 1, px, py, hexLog);
        if (ok) HidClient.saveRememberedWheelMode(1);
        runnable.addLog(new LogInfo(new NormalLog("[HID滚轮] 本机不响应 HID 滚轮，已自动切换触摸滑动(drag)并记住")), 0);
        return logResult(runnable, ok, dirIndex, ticks, "drag", hexLog);
    }

    private boolean logResult(TaskRunnable runnable, boolean ok, int dirIndex, int ticks, String tag, StringBuilder hexLog) {
        if (ok) {
            runnable.addLog(new LogInfo(new NormalLog("[HID滚轮] " + dirName(dirIndex) + " ×" + ticks + " (" + tag + ")")), 0);
        } else {
            runnable.addLog(new LogInfo(new NormalLog("[HID滚轮] 发送失败: " + hexLog)), 0);
            android.widget.Toast.makeText(MainApplication.getInstance(),
                    "[HID滚轮] 发送失败，请检查设备连接", android.widget.Toast.LENGTH_SHORT).show();
        }
        return ok;
    }

    private static Bitmap capture(TaskRunnable runnable) {
        MainAccessibilityService service = MainApplication.getInstance().getService();
        if (service == null) {
            runnable.addLog(new LogInfo(new NormalLog("[HID滚轮] 无障碍服务未运行，跳过截屏校准")), 0);
            return null;
        }
        try {
            return service.tryGetScreenShot();
        } catch (Exception e) {
            return null;
        }
    }

    // 截屏对比：缩到 24x24 采样，只看中间区域（避开状态栏时钟/信号这类常变区域）
    private static boolean screenChanged(Bitmap before, Bitmap after) {
        if (before == null || after == null) return true; // 截不了屏时保守返回"有变化"，避免误切 drag
        try {
            int w = 24, h = 24;
            Bitmap a = Bitmap.createScaledBitmap(before, w, h, true);
            Bitmap b = Bitmap.createScaledBitmap(after, w, h, true);
            long diff = 0;
            int samples = 0;
            for (int y = 3; y < h - 3; y++) {
                for (int x = 2; x < w - 2; x++) {
                    int ca = a.getPixel(x, y);
                    int cb = b.getPixel(x, y);
                    diff += Math.abs(((ca >> 16) & 0xFF) - ((cb >> 16) & 0xFF))
                            + Math.abs(((ca >> 8) & 0xFF) - ((cb >> 8) & 0xFF))
                            + Math.abs((ca & 0xFF) - (cb & 0xFF));
                    samples++;
                }
            }
            return samples > 0 && diff / samples > 6;
        } catch (Exception e) {
            return true;
        }
    }

    private static String dirName(int index) {
        return switch (index) {
            case 1 -> "下滚";
            case 2 -> "右滚";
            case 3 -> "左滚";
            default -> "上滚";
        };
    }
}
