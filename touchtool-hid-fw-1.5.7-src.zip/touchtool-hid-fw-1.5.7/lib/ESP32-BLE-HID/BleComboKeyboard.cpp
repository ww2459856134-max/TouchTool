#ifndef HID_TRACE
#define HID_TRACE 0
#endif

#include <BLEDevice.h>
#include <BLEUtils.h>
#include <BLEServer.h>
#include "BLE2902.h"
#include "BLEHIDDevice.h"
#include "HIDTypes.h"
#include <driver/adc.h>
#include "sdkconfig.h"
#include <WiFi.h>


#include "BleConnectionStatus.h"
#include "KeyboardOutputCallbacks.h"
#include "BleComboKeyboard.h"

#if defined(CONFIG_ARDUHAL_ESP_LOG)
  #include "esp32-hal-log.h"
  #define LOG_TAG ""
#else
  #include "esp_log.h"
  static const char* LOG_TAG = "BLEDevice";
#endif


// Report IDs:
#define KEYBOARD_ID 0x01
#define MEDIA_KEYS_ID 0x02
#define MOUSE_ID 0x03
#define REL_MOUSE_ID 0x04

static const uint8_t _hidReportDescriptor[] = {
  USAGE_PAGE(1),      0x01,          // USAGE_PAGE (Generic Desktop Ctrls)
  USAGE(1),           0x06,          // USAGE (Keyboard)
  COLLECTION(1),      0x01,          // COLLECTION (Application)
  // ------------------------------------------------- Keyboard
  REPORT_ID(1),       KEYBOARD_ID,   //   REPORT_ID (1)
  USAGE_PAGE(1),      0x07,          //   USAGE_PAGE (Kbrd/Keypad)
  USAGE_MINIMUM(1),   0xE0,          //   USAGE_MINIMUM (0xE0)
  USAGE_MAXIMUM(1),   0xE7,          //   USAGE_MAXIMUM (0xE7)
  LOGICAL_MINIMUM(1), 0x00,          //   LOGICAL_MINIMUM (0)
  LOGICAL_MAXIMUM(1), 0x01,          //   Logical Maximum (1)
  REPORT_SIZE(1),     0x01,          //   REPORT_SIZE (1)
  REPORT_COUNT(1),    0x08,          //   REPORT_COUNT (8)
  HIDINPUT(1),        0x02,          //   INPUT (Data,Var,Abs,No Wrap,Linear,Preferred State,No Null Position)
  REPORT_COUNT(1),    0x01,          //   REPORT_COUNT (1) ; 1 byte (Reserved)
  REPORT_SIZE(1),     0x08,          //   REPORT_SIZE (8)
  HIDINPUT(1),        0x01,          //   INPUT (Const,Array,Abs,No Wrap,Linear,Preferred State,No Null Position)
  REPORT_COUNT(1),    0x05,          //   REPORT_COUNT (5) ; 5 bits (Num lock, Caps lock, Scroll lock, Compose, Kana)
  REPORT_SIZE(1),     0x01,          //   REPORT_SIZE (1)
  USAGE_PAGE(1),      0x08,          //   USAGE_PAGE (LEDs)
  USAGE_MINIMUM(1),   0x01,          //   USAGE_MINIMUM (0x01) ; Num Lock
  USAGE_MAXIMUM(1),   0x05,          //   USAGE_MAXIMUM (0x05) ; Kana
  HIDOUTPUT(1),       0x02,          //   OUTPUT (Data,Var,Abs,No Wrap,Linear,Preferred State,No Null Position,Non-volatile)
  REPORT_COUNT(1),    0x01,          //   REPORT_COUNT (1) ; 3 bits (Padding)
  REPORT_SIZE(1),     0x03,          //   REPORT_SIZE (3)
  HIDOUTPUT(1),       0x01,          //   OUTPUT (Const,Array,Abs,No Wrap,Linear,Preferred State,No Null Position,Non-volatile)
  REPORT_COUNT(1),    0x06,          //   REPORT_COUNT (6) ; 6 bytes (Keys)
  REPORT_SIZE(1),     0x08,          //   REPORT_SIZE(8)
  LOGICAL_MINIMUM(1), 0x00,          //   LOGICAL_MINIMUM(0)
  LOGICAL_MAXIMUM(1), 0x65,          //   LOGICAL_MAXIMUM(0x65) ; 101 keys
  USAGE_PAGE(1),      0x07,          //   USAGE_PAGE (Kbrd/Keypad)
  USAGE_MINIMUM(1),   0x00,          //   USAGE_MINIMUM (0)
  USAGE_MAXIMUM(1),   0x65,          //   USAGE_MAXIMUM (0x65)
  HIDINPUT(1),        0x00,          //   INPUT (Data,Array,Abs,No Wrap,Linear,Preferred State,No Null Position)
  END_COLLECTION(0),                 // END_COLLECTION
  // ------------------------------------------------- Media Keys
  USAGE_PAGE(1),      0x0C,          // USAGE_PAGE (Consumer)
  USAGE(1),           0x01,          // USAGE (Consumer Control)
  COLLECTION(1),      0x01,          // COLLECTION (Application)
  REPORT_ID(1),       MEDIA_KEYS_ID, //   REPORT_ID (3)
  USAGE_PAGE(1),      0x0C,          //   USAGE_PAGE (Consumer)
  LOGICAL_MINIMUM(1), 0x00,          //   LOGICAL_MINIMUM (0)
  LOGICAL_MAXIMUM(1), 0x01,          //   LOGICAL_MAXIMUM (1)
  REPORT_SIZE(1),     0x01,          //   REPORT_SIZE (1)
  REPORT_COUNT(1),    0x10,          //   REPORT_COUNT (16)
  USAGE(1),           0xB5,          //   USAGE (Scan Next Track)     ; bit 0: 1
  USAGE(1),           0xB6,          //   USAGE (Scan Previous Track) ; bit 1: 2
  USAGE(1),           0xB7,          //   USAGE (Stop)                ; bit 2: 4
  USAGE(1),           0xCD,          //   USAGE (Play/Pause)          ; bit 3: 8
  USAGE(1),           0xE2,          //   USAGE (Mute)                ; bit 4: 16
  USAGE(1),           0xE9,          //   USAGE (Volume Increment)    ; bit 5: 32
  USAGE(1),           0xEA,          //   USAGE (Volume Decrement)    ; bit 6: 64
  USAGE(2),           0x23, 0x02,    //   Usage (WWW Home)            ; bit 7: 128
  USAGE(2),           0x94, 0x01,    //   Usage (My Computer) ; bit 0: 1
  USAGE(2),           0x92, 0x01,    //   Usage (Calculator)  ; bit 1: 2
  USAGE(2),           0x2A, 0x02,    //   Usage (WWW fav)     ; bit 2: 4
  USAGE(2),           0x21, 0x02,    //   Usage (WWW search)  ; bit 3: 8
  USAGE(2),           0x26, 0x02,    //   Usage (WWW stop)    ; bit 4: 16
  USAGE(2),           0x24, 0x02,    //   Usage (WWW back)    ; bit 5: 32
  USAGE(2),           0x83, 0x01,    //   Usage (Media sel)   ; bit 6: 64
  USAGE(2),           0x8A, 0x01,    //   Usage (Mail)        ; bit 7: 128
  HIDINPUT(1),        0x02,          //   INPUT (Data,Var,Abs,No Wrap,Linear,Preferred State,No Null Position)
  END_COLLECTION(0),                 // END_COLLECTION

  // ------------------------------------------------- ABS Mouse
  0x05, 0x0d,                    /* USAGE_PAGE (Digitizer) */
  0x09, 0x04,                    /* USAGE (Touch Screen) */
  0xa1, 0x01,                    /* COLLECTION (Application) */
  0x85, MOUSE_ID,          /*    REPORT_ID */

  /* 以下结构逐字节复刻旧版官方固件（从其固件镜像提取的报告描述符）：
   * Usage(Finger) + Collection(Logical)，含 Contact Identifier，
   * X/Y 为 16-bit、Logical Maximum 32767。Android 只对这种结构走
   * 标准触摸屏线性映射（工具=手指、坐标精确）；Self 风格的
   * Pointer/Stylus 物理集合会被当成绝对指针做等比裁切映射。 */
  0x09, 0x22,                    /*   Usage (Finger) */
  0xA1, 0x02,                    /*   Collection (Logical) */

  0x09, 0x42,                    /*     Usage (Tip Switch) */
  0x09, 0x32,                    /*     Usage (In Range) */
  0x15, 0x00,                    /*     Logical Min (0) */
  0x25, 0x01,                    /*     Logical Max (1) */
  0x75, 0x01,                    /*     Report Size (1) */
  0x95, 0x02,                    /*     Report Count (2) */
  0x81, 0x02,                    /*     Input (Data,Var,Abs) */

  0x75, 0x01,                    /*     Report Size (1) */
  0x95, 0x06,                    /*     Report Count (6) */
  0x81, 0x01,                    /*     Input (Const,Ary,Abs) */

  0x09, 0x51,                    /*     Usage (Contact Identifier) */
  0x75, 0x08,                    /*     Report Size (8) */
  0x95, 0x01,                    /*     Report Count (1) */
  0x15, 0x00,                    /*     Logical Min (0) */
  0x25, 0x7f,                    /*     Logical Max (127) */
  0x81, 0x02,                    /*     Input (Data,Var,Abs) */

  0x05, 0x01,                    /*     Usage Page (Generic Desktop) */
  0x09, 0x30,                    /*     Usage (X) */
  0x09, 0x31,                    /*     Usage (Y) */
  0x16, 0x00, 0x00,              /*     Logical Minimum (0) */
  0x26, 0xff, 0x7f,              /*     Logical Maximum (32767) */
  0x75, 0x10,                    /*     Report Size (16) */
  0x95, 0x02,                    /*     Report Count (2) */
  0x81, 0x02,                    /*     Input (Data,Var,Abs) */
  0xc0,                          /*   END_COLLECTION (Logical) */
  0xc0,                           /* END_COLLECTION (Application) */

  // With this declaration a data packet must be sent as:
  // byte 1   -> "touch" state          (bit 0 = pen up/down, bit 1 = In Range)
  // byte 2,3 -> absolute X coordinate  (0...10000)
  // byte 4,5 -> absolute Y coordinate  (0...10000)
//----------------REL Mouse
 USAGE_PAGE(1),       0x01, // USAGE_PAGE (Generic Desktop)
 USAGE(1),            0x02, // USAGE (Mouse)
 COLLECTION(1),       0x01, // COLLECTION (Application)
 USAGE(1),            0x01, //   USAGE (Pointer)
 COLLECTION(1),       0x00, //   COLLECTION (Physical)
 REPORT_ID(1),        REL_MOUSE_ID, //     REPORT_ID (4)
 // ------------------------------------------------- Buttons (Left, Right, Middle, Back, Forward)
 USAGE_PAGE(1),       0x09, //     USAGE_PAGE (Button)
 USAGE_MINIMUM(1),    0x01, //     USAGE_MINIMUM (Button 1)
 USAGE_MAXIMUM(1),    0x05, //     USAGE_MAXIMUM (Button 5)
 LOGICAL_MINIMUM(1),  0x00, //     LOGICAL_MINIMUM (0)
 LOGICAL_MAXIMUM(1),  0x01, //     LOGICAL_MAXIMUM (1)
 REPORT_SIZE(1),      0x01, //     REPORT_SIZE (1)
 REPORT_COUNT(1),     0x05, //     REPORT_COUNT (5)
 HIDINPUT(1),         0x02, //     INPUT (Data, Variable, Absolute) ;5 button bits
 // ------------------------------------------------- Padding
 REPORT_SIZE(1),      0x03, //     REPORT_SIZE (3)
 REPORT_COUNT(1),     0x01, //     REPORT_COUNT (1)
 HIDINPUT(1),         0x03, //     INPUT (Constant, Variable, Absolute) ;3 bit padding
 // ------------------------------------------------- X/Y position, Wheel
 USAGE_PAGE(1),       0x01, //     USAGE_PAGE (Generic Desktop)
 USAGE(1),            0x30, //     USAGE (X)
 USAGE(1),            0x31, //     USAGE (Y)
 USAGE(1),            0x38, //     USAGE (Wheel)
 LOGICAL_MINIMUM(1),  0x81, //     LOGICAL_MINIMUM (-127)
 LOGICAL_MAXIMUM(1),  0x7f, //     LOGICAL_MAXIMUM (127)
 REPORT_SIZE(1),      0x08, //     REPORT_SIZE (8)
 REPORT_COUNT(1),     0x03, //     REPORT_COUNT (3)
 HIDINPUT(1),         0x06, //     INPUT (Data, Variable, Relative) ;3 bytes (X,Y,Wheel)
 // ------------------------------------------------- Horizontal wheel
 USAGE_PAGE(1),       0x0c, //     USAGE PAGE (Consumer Devices)
 USAGE(2),      0x38, 0x02, //     USAGE (AC Pan)
 LOGICAL_MINIMUM(1),  0x81, //     LOGICAL_MINIMUM (-127)
 LOGICAL_MAXIMUM(1),  0x7f, //     LOGICAL_MAXIMUM (127)
 REPORT_SIZE(1),      0x08, //     REPORT_SIZE (8)
 REPORT_COUNT(1),     0x01, //     REPORT_COUNT (1)
 HIDINPUT(1),         0x06, //     INPUT (Data, Var, Rel)
 END_COLLECTION(0),         //   END_COLLECTION
 END_COLLECTION(0)          // END_COLLECTION

};

BleComboKeyboard::BleComboKeyboard(std::string deviceName, std::string deviceManufacturer, uint8_t batteryLevel) : hid(0)
{
  this->deviceName = deviceName;
  this->deviceManufacturer = deviceManufacturer;
  this->batteryLevel = batteryLevel;
  this->connectionStatus = new BleConnectionStatus();
}

void BleComboKeyboard::begin(void)
{
  xTaskCreate(this->taskServer, "server", 20000, (void *)this, 5, NULL);
}

void BleComboKeyboard::end(void)
{
}

bool BleComboKeyboard::isConnected(void) {
  return this->connectionStatus->connected;
}

void BleComboKeyboard::setBatteryLevel(uint8_t level) {
  this->batteryLevel = level;
  if (hid != 0)
    this->hid->setBatteryLevel(this->batteryLevel);
}

BLECharacteristicCallbacks* globalCallbacks = nullptr;
void BleComboKeyboard::setCallbacks(BLECharacteristicCallbacks *callbacks) {
	globalCallbacks=callbacks;
}




void BleComboKeyboard::taskServer(void* pvParameter) {
  BleComboKeyboard* bleKeyboardInstance = (BleComboKeyboard *) pvParameter; //static_cast<BleComboKeyboard *>(pvParameter);
  BLEDevice::init(bleKeyboardInstance->deviceName.c_str());
  BLEDevice::setMTU(247);   // v1.5.4: 与 App requestMtu(247) 对齐，指令单包更大、每包开销更低
  BLEServer *pServer = BLEDevice::createServer();
  pServer->setCallbacks(bleKeyboardInstance->connectionStatus);

  bleKeyboardInstance->hid = new BLEHIDDevice(pServer);
  bleKeyboardInstance->inputKeyboard = bleKeyboardInstance->hid->inputReport(KEYBOARD_ID); // <-- input REPORTID from report map
  bleKeyboardInstance->outputKeyboard = bleKeyboardInstance->hid->outputReport(KEYBOARD_ID);
  bleKeyboardInstance->inputMediaKeys = bleKeyboardInstance->hid->inputReport(MEDIA_KEYS_ID);
  bleKeyboardInstance->connectionStatus->inputKeyboard = bleKeyboardInstance->inputKeyboard;
  bleKeyboardInstance->connectionStatus->outputKeyboard = bleKeyboardInstance->outputKeyboard;

  // 依赖核心补丁（见 patches/README.md）：NimBLE 去重被放开，重复 0x2A4D 可注册
  bleKeyboardInstance->inputMouse = bleKeyboardInstance->hid->inputReport(MOUSE_ID);
  bleKeyboardInstance->connectionStatus->inputMouse = bleKeyboardInstance->inputMouse;

  bleKeyboardInstance->inputRELMouse = bleKeyboardInstance->hid->inputReport(REL_MOUSE_ID);
  bleKeyboardInstance->connectionStatus->inputRELMouse = bleKeyboardInstance->inputRELMouse;

  bleKeyboardInstance->outputKeyboard->setCallbacks(new KeyboardOutputCallbacks());

  bleKeyboardInstance->hid->manufacturer()->setValue(bleKeyboardInstance->deviceManufacturer.c_str());

  bleKeyboardInstance->hid->pnp(0x02, 0xe502, 0xa111, 0x0210);
  bleKeyboardInstance->hid->hidInfo(0x00,0x01);

  // 安全参数：原来只设了 ESP_LE_AUTH_BOND（传统配对、无 SC），
  // Android 11+ 对 HID 外设较严格，传统配对容易被对端直接拒绝，
  // 表现为"点配对转几秒连接被断开"。改为 LE Secure Connections + 绑定，
  // IO 能力设为 NONE（无屏无键盘）→ 仍是 Just Works，不需要配对码。
  BLESecurity::setCapability(ESP_IO_CAP_NONE);
  BLESecurity::setKeySize(16);
  // 同时分发加密密钥与身份密钥：Android 回连时常用可解析私有地址(RPA)，
  // 没有 ID 密钥就无法把自己认回来，会表现为"配对成功但下次连不上"。
  BLESecurity::setInitEncryptionKey(ESP_BLE_ENC_KEY_MASK | ESP_BLE_ID_KEY_MASK);
  BLESecurity::setRespEncryptionKey(ESP_BLE_ENC_KEY_MASK | ESP_BLE_ID_KEY_MASK);
  BLESecurity::setAuthenticationMode(true /*bonding*/, false /*mitm*/, true /*secure connections*/);

  bleKeyboardInstance->hid->reportMap((uint8_t*)_hidReportDescriptor, sizeof(_hidReportDescriptor));

  // v1.2.4 fix: 自定义指令服务必须在 startServices()（即 ble_gatts_start）之前
  // 创建并 start——NimBLE 在 ble_gatts_start 之后拒绝 ble_gatts_add_svcs，
  // 之前的写法服务被静默丢弃，nRF Connect / App 都看不到 beb5483e 特征。
  BLEService* pService = pServer->createService("4fafc201-1fb5-459e-8fcc-c5c9c331914b");
  BLECharacteristic* pCharacteristic = pService->createCharacteristic(
      "beb5483e-36e1-4688-b7f5-ea07361b26a8",
      BLECharacteristic::PROPERTY_READ |
      BLECharacteristic::PROPERTY_WRITE |
      BLECharacteristic::PROPERTY_WRITE_NR   // 免响应写，App 指令低延迟
  );
  pCharacteristic->setCallbacks(globalCallbacks);
  pService->start();

  bleKeyboardInstance->hid->startServices();

  BLEAdvertising *pAdvertising = pServer->getAdvertising();
  pAdvertising->setAppearance(HID_KEYBOARD);
  pAdvertising->addServiceUUID(bleKeyboardInstance->hid->hidService()->getUUID());
	pAdvertising->addServiceUUID(pService->getUUID());
	pAdvertising->setScanResponse(true);
	pAdvertising->setMinPreferred(0x06);  
  pAdvertising->start();
  {
    extern void hidDiag(const char *tag, BLECharacteristic *c);
    extern BLEService* g_hidSvc;
    g_hidSvc = bleKeyboardInstance->hid->hidService();
    hidDiag("svc-started kb", bleKeyboardInstance->inputKeyboard);
    hidDiag("svc-started mouse", bleKeyboardInstance->inputMouse);
    hidDiag("svc-started relmouse", bleKeyboardInstance->inputRELMouse);
  }
  bleKeyboardInstance->hid->setBatteryLevel(bleKeyboardInstance->batteryLevel);

  ESP_LOGD(LOG_TAG, "Advertising started!");
  vTaskDelay(portMAX_DELAY); 
}

// ============ 1.1.6 HID 安全发送 ============
// 1.1.5 的 panic 在 BLECharacteristic::notify() 内部读特征对象里损坏的
// service 指针。这里不再走那条指针链：
//   * gatts_if 从 ESP_GATTS_REG_EVT 抓（getGattsIf 在核心库是 private）
//   * conn_id 从 BLEServer::getConnId() 拿（public）
//   * 直接调 esp_ble_gatts_send_indicate 发报告
// 发送前后把指针/句柄值写进主程序的 /blelog 轨迹，坏数据当场现形。
extern void traceAppend(const char *line);
extern uint32_t hidSendCount, hidSkipCount, lastHidSendAt;

BLEService *g_hidSvc = nullptr;

void hidInitDiag() {
  // NimBLE 模式下无需额外初始化；保留入口以便以后扩展
}

void hidDiag(const char *tag, BLECharacteristic *c) {
  char line[128];
  snprintf(line, sizeof(line), "[%lus] DIAG %s chr=%p hnd=%u svc=%p\n",
           (unsigned long) (millis() / 1000), tag, c,
           (unsigned) ((c != nullptr) ? c->getHandle() : 0),
           (void *) g_hidSvc);
  traceAppend(line);
  Serial.print("[HID-TRACE] ");
  Serial.print(line);
}

bool hidSafeNotify(BLECharacteristic *c, const char *tag, const uint8_t *data, size_t len) {
  char line[128];
  BLEServer *srv = (g_hidSvc != nullptr) ? g_hidSvc->getServer() : nullptr;
  uint16_t handle = (c != nullptr) ? c->getHandle() : 0;
  uint16_t conn = (srv != nullptr) ? srv->getConnId() : ESP_GATT_IF_NONE;
  int clients = (srv != nullptr) ? (int) srv->getConnectedCount() : -1;
  bool ok = (c != nullptr) && (g_hidSvc != nullptr) && (srv != nullptr)
            && handle != 0xFFFF && len > 0 && len <= 32 && clients > 0
            && conn != ESP_GATT_IF_NONE;
  // v1.2.10: 逐帧日志默认关闭（每帧触摸都写 trace + 串口，开销大且抖动蓝牙时序）。
  // 排查时在编译命令加 -DHID_TRACE=1 重新打开。
#if HID_TRACE
  snprintf(line, sizeof(line), "[%lus] HID %s chr=%p hnd=%u conn=%u clients=%d len=%u\n",
           (unsigned long) (millis() / 1000), tag, c, (unsigned) handle,
           (unsigned) conn, clients, (unsigned) len);
  traceAppend(line);
  Serial.print("[HID-TRACE] ");
  Serial.print(line);
#endif
  if (!ok) {
    hidSkipCount++;
    return false;
  }
  // NimBLE 原生发送：绕开 BLECharacteristic::notify() 内部损坏的指针链，
  // 也绕开它 getValue() -> Arduino String 会把 0x00 字节截断的问题
  // （鼠标报告里 x/y 低位经常是 0x00，必须按原始字节发）。
  struct os_mbuf *om = os_msys_get_pkthdr(len, 0);
  if (om == nullptr) {
    snprintf(line, sizeof(line), "[%lus] HID %s mbuf alloc failed\n",
             (unsigned long) (millis() / 1000), tag);
    traceAppend(line);
    Serial.print("[HID-TRACE] ");
    Serial.print(line);
    hidSkipCount++;
    return false;
  }
  if (os_mbuf_append(om, data, len) != 0) {
    os_mbuf_free_chain(om);
    snprintf(line, sizeof(line), "[%lus] HID %s mbuf append failed\n",
             (unsigned long) (millis() / 1000), tag);
    traceAppend(line);
    Serial.print("[HID-TRACE] ");
    Serial.print(line);
    hidSkipCount++;
    return false;
  }
  // om 的所有权移交给协议栈（失败时也会被释放）
  int rc = ble_gatts_notify_custom(conn, handle, om);
  if (rc != 0) {
    snprintf(line, sizeof(line), "[%lus] HID %s notify rc=%d\n",
             (unsigned long) (millis() / 1000), tag, rc);
    traceAppend(line);
    Serial.print("[HID-TRACE] ");
    Serial.print(line);
    hidSkipCount++;
    return false;
  }
  hidSendCount++;
  lastHidSendAt = millis();
  return true;
}
// ============ 1.1.6 安全发送结束 ============

void BleComboKeyboard::sendReport(KeyReport* keys)
{
  if (this->isConnected())
  {
    this->inputKeyboard->setValue((uint8_t*)keys, sizeof(KeyReport));
    hidSafeNotify(this->inputKeyboard, "keys", (uint8_t*)keys, sizeof(KeyReport));
  }
}

void BleComboKeyboard::sendReport(MediaKeyReport* keys)
{
  if (this->isConnected())
  {
    this->inputMediaKeys->setValue((uint8_t*)keys, sizeof(MediaKeyReport));
    this->inputMediaKeys->notify();
  }
}

extern
const uint8_t _asciimap[128] PROGMEM;

#define SHIFT 0x80
const uint8_t _asciimap[128] =
{
	0x00,             // NUL
	0x00,             // SOH
	0x00,             // STX
	0x00,             // ETX
	0x00,             // EOT
	0x00,             // ENQ
	0x00,             // ACK
	0x00,             // BEL
	0x2a,			// BS	Backspace
	0x2b,			// TAB	Tab
	0x28,			// LF	Enter
	0x00,             // VT
	0x00,             // FF
	0x00,             // CR
	0x00,             // SO
	0x00,             // SI
	0x00,             // DEL
	0x00,             // DC1
	0x00,             // DC2
	0x00,             // DC3
	0x00,             // DC4
	0x00,             // NAK
	0x00,             // SYN
	0x00,             // ETB
	0x00,             // CAN
	0x00,             // EM
	0x00,             // SUB
	0x00,             // ESC
	0x00,             // FS
	0x00,             // GS
	0x00,             // RS
	0x00,             // US

	0x2c,		   //  ' '
	0x1e|SHIFT,	   // !
	0x34|SHIFT,	   // "
	0x20|SHIFT,    // #
	0x21|SHIFT,    // $
	0x22|SHIFT,    // %
	0x24|SHIFT,    // &
	0x34,          // '
	0x26|SHIFT,    // (
	0x27|SHIFT,    // )
	0x25|SHIFT,    // *
	0x2e|SHIFT,    // +
	0x36,          // ,
	0x2d,          // -
	0x37,          // .
	0x38,          // /
	0x27,          // 0
	0x1e,          // 1
	0x1f,          // 2
	0x20,          // 3
	0x21,          // 4
	0x22,          // 5
	0x23,          // 6
	0x24,          // 7
	0x25,          // 8
	0x26,          // 9
	0x33|SHIFT,      // :
	0x33,          // ;
	0x36|SHIFT,      // <
	0x2e,          // =
	0x37|SHIFT,      // >
	0x38|SHIFT,      // ?
	0x1f|SHIFT,      // @
	0x04|SHIFT,      // A
	0x05|SHIFT,      // B
	0x06|SHIFT,      // C
	0x07|SHIFT,      // D
	0x08|SHIFT,      // E
	0x09|SHIFT,      // F
	0x0a|SHIFT,      // G
	0x0b|SHIFT,      // H
	0x0c|SHIFT,      // I
	0x0d|SHIFT,      // J
	0x0e|SHIFT,      // K
	0x0f|SHIFT,      // L
	0x10|SHIFT,      // M
	0x11|SHIFT,      // N
	0x12|SHIFT,      // O
	0x13|SHIFT,      // P
	0x14|SHIFT,      // Q
	0x15|SHIFT,      // R
	0x16|SHIFT,      // S
	0x17|SHIFT,      // T
	0x18|SHIFT,      // U
	0x19|SHIFT,      // V
	0x1a|SHIFT,      // W
	0x1b|SHIFT,      // X
	0x1c|SHIFT,      // Y
	0x1d|SHIFT,      // Z
	0x2f,          // [
	0x31,          // bslash
	0x30,          // ]
	0x23|SHIFT,    // ^
	0x2d|SHIFT,    // _
	0x35,          // `
	0x04,          // a
	0x05,          // b
	0x06,          // c
	0x07,          // d
	0x08,          // e
	0x09,          // f
	0x0a,          // g
	0x0b,          // h
	0x0c,          // i
	0x0d,          // j
	0x0e,          // k
	0x0f,          // l
	0x10,          // m
	0x11,          // n
	0x12,          // o
	0x13,          // p
	0x14,          // q
	0x15,          // r
	0x16,          // s
	0x17,          // t
	0x18,          // u
	0x19,          // v
	0x1a,          // w
	0x1b,          // x
	0x1c,          // y
	0x1d,          // z
	0x2f|SHIFT,    // {
	0x31|SHIFT,    // |
	0x30|SHIFT,    // }
	0x35|SHIFT,    // ~
	0				// DEL
};


uint8_t USBPutChar(uint8_t c);

// press() adds the specified key (printing, non-printing, or modifier)
// to the persistent key report and sends the report.  Because of the way
// USB HID works, the host acts like the key remains pressed until we
// call release(), releaseAll(), or otherwise clear the report and resend.
size_t BleComboKeyboard::press(uint8_t k)
{
	uint8_t i;
	if (k >= 136) {			// it's a non-printing key (not a modifier)
		k = k - 136;
	} else if (k >= 128) {	// it's a modifier key
		_keyReport.modifiers |= (1<<(k-128));
		k = 0;
	} else {				// it's a printing key
		k = pgm_read_byte(_asciimap + k);
		if (!k) {
			setWriteError();
			return 0;
		}
		if (k & 0x80) {						// it's a capital letter or other character reached with shift
			_keyReport.modifiers |= 0x02;	// the left shift modifier
			k &= 0x7F;
		}
	}

	// Add k to the key report only if it's not already present
	// and if there is an empty slot.
	if (_keyReport.keys[0] != k && _keyReport.keys[1] != k &&
		_keyReport.keys[2] != k && _keyReport.keys[3] != k &&
		_keyReport.keys[4] != k && _keyReport.keys[5] != k) {

		for (i=0; i<6; i++) {
			if (_keyReport.keys[i] == 0x00) {
				_keyReport.keys[i] = k;
				break;
			}
		}
		if (i == 6) {
			setWriteError();
			return 0;
		}
	}
	sendReport(&_keyReport);
	return 1;
}

size_t BleComboKeyboard::press(const MediaKeyReport k)
{
    uint16_t k_16 = k[1] | (k[0] << 8);
    uint16_t mediaKeyReport_16 = _mediaKeyReport[1] | (_mediaKeyReport[0] << 8);

    mediaKeyReport_16 |= k_16;
    _mediaKeyReport[0] = (uint8_t)((mediaKeyReport_16 & 0xFF00) >> 8);
    _mediaKeyReport[1] = (uint8_t)(mediaKeyReport_16 & 0x00FF);

	sendReport(&_mediaKeyReport);
	return 1;
}

// release() takes the specified key out of the persistent key report and
// sends the report.  This tells the OS the key is no longer pressed and that
// it shouldn't be repeated any more.
size_t BleComboKeyboard::release(uint8_t k)
{
	uint8_t i;
	if (k >= 136) {			// it's a non-printing key (not a modifier)
		k = k - 136;
	} else if (k >= 128) {	// it's a modifier key
		_keyReport.modifiers &= ~(1<<(k-128));
		k = 0;
	} else {				// it's a printing key
		k = pgm_read_byte(_asciimap + k);
		if (!k) {
			return 0;
		}
		if (k & 0x80) {							// it's a capital letter or other character reached with shift
			_keyReport.modifiers &= ~(0x02);	// the left shift modifier
			k &= 0x7F;
		}
	}

	// Test the key report to see if k is present.  Clear it if it exists.
	// Check all positions in case the key is present more than once (which it shouldn't be)
	for (i=0; i<6; i++) {
		if (0 != k && _keyReport.keys[i] == k) {
			_keyReport.keys[i] = 0x00;
		}
	}

	sendReport(&_keyReport);
	return 1;
}

size_t BleComboKeyboard::release(const MediaKeyReport k)
{
    uint16_t k_16 = k[1] | (k[0] << 8);
    uint16_t mediaKeyReport_16 = _mediaKeyReport[1] | (_mediaKeyReport[0] << 8);
    mediaKeyReport_16 &= ~k_16;
    _mediaKeyReport[0] = (uint8_t)((mediaKeyReport_16 & 0xFF00) >> 8);
    _mediaKeyReport[1] = (uint8_t)(mediaKeyReport_16 & 0x00FF);

	sendReport(&_mediaKeyReport);
	return 1;
}

void BleComboKeyboard::releaseAll(void)
{
	_keyReport.keys[0] = 0;
	_keyReport.keys[1] = 0;
	_keyReport.keys[2] = 0;
	_keyReport.keys[3] = 0;
	_keyReport.keys[4] = 0;
	_keyReport.keys[5] = 0;
	_keyReport.modifiers = 0;
    _mediaKeyReport[0] = 0;
    _mediaKeyReport[1] = 0;
	sendReport(&_keyReport);
}

size_t BleComboKeyboard::write(uint8_t c)
{
	uint8_t p = press(c);  // Keydown
	release(c);            // Keyup
	return p;              // just return the result of press() since release() almost always returns 1
}

size_t BleComboKeyboard::write(const MediaKeyReport c)
{
	uint16_t p = press(c);  // Keydown
	release(c);            // Keyup
	return p;              // just return the result of press() since release() almost always returns 1
}

size_t BleComboKeyboard::write(const uint8_t *buffer, size_t size) {
	size_t n = 0;
	while (size--) {
		if (*buffer != '\r') {
			if (write(*buffer)) {
			  n++;
			} else {
			  break;
			}
		}
		buffer++;
	}
	return n;
}

